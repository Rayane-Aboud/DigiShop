import openai

openai.api_key="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"

completion = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[{"role":"user","content":"what is the circumctance of the moon in km?"}]
)

print(completion)



