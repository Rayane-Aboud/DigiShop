from flask import Blueprint, render_template, request
from app.routes.user_bp import user_bp
from app.routes.product_bp import product_bp
from app.models.model import Product
from app import app,db



main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def home():
    page = request.args.get('page',1,type=int)
    products=Product.query.order_by(Product.date_posted.desc()).paginate(page=page,per_page = 5)
    return render_template('index.html', title='Home',products=products)


@main_bp.route('/about')
def about():
    return render_template('home/about.html', title='About')




app.register_blueprint(main_bp)
app.register_blueprint(user_bp)
app.register_blueprint(product_bp)