from flask_wtf import FlaskForm
from flask_wtf.file import FileField,FileAllowed
from wtforms import StringField,SubmitField,TextAreaField,HiddenField
from wtforms.validators import DataRequired, Length,EqualTo,ValidationError


#form that is used to create products
class ProductForm(FlaskForm):
    product_name = StringField('product name',validators=[DataRequired()])
    price = StringField('price :',validators=[DataRequired()])
    picture = FileField('Update profile picture',validators=[FileAllowed(['jpg','jpeg','png'])])
    period = StringField('period (per day,per month,per year,else just leave it empty ^_^)',validators=[])
    description = TextAreaField('description',validators=[DataRequired()])
    submit=SubmitField('Add product to the market')
    
    def validate_price(self,price):
        if not price.data.isdigit():
            raise ValidationError('invalid price input')
        if float (price.data) < 0:
            raise ValidationError('invalid price input')
        


#delete the product
class DeleteProductForm(FlaskForm):
    product_id = HiddenField('Product ID')
    submit = SubmitField('Delete for good')